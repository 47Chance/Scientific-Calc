import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;




public class CalculatorLayout extends JFrame implements ActionListener {
	private JButton bOne = new JButton("1");
	private JButton bTwo = new JButton("2");
	private JButton bThree = new JButton("3");
	private JButton bFour = new JButton("4");
	private JButton bFive = new JButton("5");
	private JButton bSix = new JButton("6");
	private JButton bSeven = new JButton("7");
	private JButton bEight = new JButton("8");
	private JButton bNine = new JButton("9");
	private JButton bZero = new JButton("0");
	private JButton bMul = new JButton("\u00D7");
	private JButton bDiv = new JButton("\u00F7");
	private JButton bAdd = new JButton("+");
	private JButton bSub = new JButton("\u02D7");
	private JButton bEqual = new JButton("=");
	private JButton bPoint = new JButton(".");
	private JButton bClear = new JButton("C");
	private JButton bSquare = new JButton("x\u00B2");
	private JButton bCube = new JButton("x\u00B3");
	private JButton bSqrt = new JButton("\u221A");
	private JButton bPercent = new JButton("%");
	private JButton bMod = new JButton("Mod");
	private JButton bOneByN = new JButton("1/n");
	private JButton bPlusMinus = new JButton("\u00B1");
	
			
	private JButton bSin = new JButton("sin");
	private JButton bCos = new JButton("cos");
	private JButton bTan = new JButton("tan");
	private JButton bAsin = new JButton("asin");
	private JButton bAcos = new JButton("acos");
	private JButton bAtan = new JButton("atan");
	private JButton bSinH = new JButton("sinh");
	private JButton bCosH = new JButton("cosh");
	private JButton bTanH = new JButton("tanh");
	private JButton bPowerOfTen = new JButton("10^n");
	private JButton bLog = new JButton("log");
	private JButton bLn = new JButton("ln");
	private JButton bAbs = new JButton("abs");
	private JButton bExit = new JButton("EXIT");
	
			
	private JTextField tfDisplay = new JTextField();
	private JTextField tfRawInput = new JTextField();
	private String sRawInput = "";
	private String sDisplay = "";
	private boolean isPlus = true;
	private boolean isPoint = false;
	private boolean isOperation = false;
	private double number1 = 0;
	private double number2 = 0;
	private double result = 0;
	private char operation = ' ';
	static Color windowColor = new Color(110, 119, 129);

	
	
	public CalculatorLayout()
	{
		setBackground(windowColor);
		setLayout(null);
		JPanel pScreen1 = new JPanel(); 
		JPanel pScreen2 = new JPanel(); 
		JPanel pKeypad1 = new JPanel(); 
		JPanel pKeypad2 = new JPanel();
		
		
		Font fontResDisplay = new Font("Times New Roman", Font.BOLD, 35);
		Font fontKeypad = new Font("Times New Roman", Font.PLAIN, 20);
		Font fontKeypad1 = new Font("Times New Roman", Font.PLAIN, 15);
		
		Color screenColor = new Color(91, 178, 91);
		Color numberKeyColor = new Color(212, 212, 212);
		Color equalColor = new Color(91, 178, 91);
		Color exitColor = new Color(212, 212, 212);
		Color otherColor = new Color(106, 118, 229);
	
		
				
		add(pScreen1).setBounds(0, 0, 343, 30);
		pScreen1.add(tfRawInput);
		pScreen1.setLayout(null);
		tfRawInput.setBounds(0, 0, 343, 30);
		tfRawInput.setHorizontalAlignment(JTextField.LEFT);
		tfRawInput.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		tfRawInput.setText("0");
		tfRawInput.setEditable(false);
		tfRawInput.setBackground(screenColor);
		tfRawInput.setForeground(Color.BLACK);
		
		add(pScreen2).setBounds(0, 30, 343, 50);
		pScreen2.add(tfDisplay);
		pScreen2.setLayout(null);
		tfDisplay.setBounds(0, 0, 343, 50);
		tfDisplay.setHorizontalAlignment(JTextField.RIGHT);
		tfDisplay.setFont(fontResDisplay);
		tfDisplay.setText("0");
		tfDisplay.setEditable(false);
		tfDisplay.setBackground(screenColor);
		tfDisplay.setForeground(Color.BLACK);

		
		add(pKeypad1).setBounds(0, 100, 343, 190);
		pKeypad1.setLayout(null);
		pKeypad1.setBackground(windowColor);
		
		
		bOne.setFont(fontKeypad);	bOne.setBackground(numberKeyColor);	bOne.setFocusable(false);
		bTwo.setFont(fontKeypad);	bTwo.setBackground(numberKeyColor);	bTwo.setFocusable(false);
		bThree.setFont(fontKeypad);	bThree.setBackground(numberKeyColor);	bThree.setFocusable(false);
		bFour.setFont(fontKeypad);	bFour.setBackground(numberKeyColor);	bFour.setFocusable(false);
		bFive.setFont(fontKeypad);	bFive.setBackground(numberKeyColor);	bFive.setFocusable(false);
		bSix.setFont(fontKeypad);	bSix.setBackground(numberKeyColor);	bSix.setFocusable(false);
		bSeven.setFont(fontKeypad);	bSeven.setBackground(numberKeyColor);	bSeven.setFocusable(false);
		bEight.setFont(fontKeypad);	bEight.setBackground(numberKeyColor);	bEight.setFocusable(false);
		bNine.setFont(fontKeypad);	bNine.setBackground(numberKeyColor);	bNine.setFocusable(false);
		bZero.setFont(fontKeypad);	bZero.setBackground(numberKeyColor);	bZero.setFocusable(false);
		bAdd.setFont(fontKeypad);	bAdd.setBackground(otherColor);	bAdd.setFocusable(false);
		bSub.setFont(fontKeypad);	bSub.setBackground(otherColor);	bSub.setFocusable(false);
		bMul.setFont(fontKeypad);	bMul.setBackground(otherColor);	bMul.setFocusable(false);
		bDiv.setFont(fontKeypad);	bDiv.setBackground(otherColor);	bDiv.setFocusable(false);
		bPoint.setFont(fontKeypad);	bPoint.setBackground(numberKeyColor);	bPoint.setFocusable(false);
		bEqual.setFont(new Font("Times New Roman", Font.PLAIN, 40));	bEqual.setBackground(equalColor);	bEqual.setFocusable(false);
		bClear.setFont(fontKeypad);	bClear.setBackground(exitColor);	bClear.setFocusable(false);
		bSquare.setFont(fontKeypad);	bSquare.setBackground(otherColor);	bSquare.setFocusable(false);
		bSqrt.setFont(fontKeypad);	bSqrt.setBackground(otherColor);	bSqrt.setFocusable(false);
		bCube.setFont(fontKeypad);	bCube.setBackground(otherColor);	bCube.setFocusable(false);
		bPercent.setFont(fontKeypad);	bPercent.setBackground(otherColor);	bPercent.setFocusable(false);
		bMod.setFont(new Font("Times New Roman", Font.PLAIN, 10));  bMod.setBackground(otherColor);	bMod.setFocusable(false);
		bOneByN.setFont(fontKeypad1);	bOneByN.setBackground(otherColor);	bOneByN.setFocusable(false);
		bPlusMinus.setFont(fontKeypad);	bPlusMinus.setBackground(numberKeyColor);	bPlusMinus.setFocusable(false);
		
		
		
	
		
		pKeypad1.add(bClear).setBounds(280, 0, 54, 38);
		
		pKeypad1.add(bSeven).setBounds(10, 38, 54, 38);pKeypad1.add(bEight).setBounds(64, 38, 54, 38);pKeypad1.add(bNine).setBounds(118, 38, 54, 38);	
		pKeypad1.add(bMul).setBounds(172, 38, 54, 38);pKeypad1.add(bDiv).setBounds(226, 38, 54, 38);pKeypad1.add(bSquare).setBounds(280, 38, 54, 38);
		
		pKeypad1.add(bFour).setBounds(10, 76, 54, 38);pKeypad1.add(bFive).setBounds(64, 76, 54, 38);pKeypad1.add(bSix).setBounds(118, 76, 54, 38);
		pKeypad1.add(bAdd).setBounds(172, 76, 54, 38);pKeypad1.add(bSub).setBounds(226, 76, 54, 38);pKeypad1.add(bCube).setBounds(280, 76, 54, 38);
		
		pKeypad1.add(bOne).setBounds(10, 114, 54, 38);pKeypad1.add(bTwo).setBounds(64, 114, 54, 38);pKeypad1.add(bThree).setBounds(118, 114, 54, 38);
		pKeypad1.add(bEqual).setBounds(172, 114, 108, 38);pKeypad1.add(bMod).setBounds(280, 114, 54, 38);
	
		pKeypad1.add(bZero).setBounds(10, 152, 54, 38);pKeypad1.add(bPoint).setBounds(64, 152, 54, 38);pKeypad1.add(bPlusMinus).setBounds(118, 152, 54, 38);
		pKeypad1.add(bOneByN).setBounds(172, 152, 54, 38);pKeypad1.add(bPercent).setBounds(226, 152, 54, 38);pKeypad1.add(bSqrt).setBounds(280, 152, 54, 38);	
		
		add(pKeypad2).setBounds(0, 310, 343, 145);
		pKeypad2.setLayout(null);
		pKeypad2.setBackground(windowColor);
		pKeypad2.add(bSin).setBounds(10, 0, 65, 38);pKeypad2.add(bCos).setBounds(75, 0, 65, 38);pKeypad2.add(bTan).setBounds(140, 0, 65, 38);
		pKeypad2.add(bLog).setBounds(205, 0, 65, 38);pKeypad2.add(bLn).setBounds(270, 0, 64, 38);
		pKeypad2.add(bAsin).setBounds(10, 38, 65, 38);pKeypad2.add(bAcos).setBounds(75, 38, 65, 38);pKeypad2.add(bAtan).setBounds(140, 38, 65, 38);
		pKeypad2.add(bPowerOfTen).setBounds(205, 38, 65, 38);pKeypad2.add(bAbs).setBounds(270, 38, 64, 38);
		pKeypad2.add(bSinH).setBounds(10, 76, 65, 38);pKeypad2.add(bCosH).setBounds(75, 76, 65, 38);pKeypad2.add(bTanH).setBounds(140, 76, 65, 38);
		pKeypad2.add(bExit).setBounds(205, 76, 130, 38);
		

		bSin.setFont(fontKeypad);	bSin.setBackground(otherColor);	bSin.setFocusable(false);
		bCos.setFont(fontKeypad);	bCos.setBackground(otherColor);	bCos.setFocusable(false);
		bTan.setFont(fontKeypad);	bTan.setBackground(otherColor);	bTan.setFocusable(false);
		bAsin.setFont(fontKeypad1);	bAsin.setBackground(otherColor);	bAsin.setFocusable(false);
		bAcos.setFont(fontKeypad1);	bAcos.setBackground(otherColor);	bAcos.setFocusable(false);
		bAtan.setFont(fontKeypad1);	bAtan.setBackground(otherColor);	bAtan.setFocusable(false);
		bSinH.setFont(fontKeypad1);	bSinH.setBackground(otherColor);	bSinH.setFocusable(false);
		bCosH.setFont(fontKeypad1);	bCosH.setBackground(otherColor);	bCosH.setFocusable(false);
		bTanH.setFont(fontKeypad1);	bTanH.setBackground(otherColor);	bTanH.setFocusable(false);
		bLog.setFont(fontKeypad);	bLog.setBackground(otherColor);	bLog.setFocusable(false);
		bLn.setFont(fontKeypad);	bLn.setBackground(otherColor);		bLn.setFocusable(false);
		bAbs.setFont(fontKeypad);	bAbs.setBackground(otherColor);	bAbs.setFocusable(false);
		bExit.setFont(fontKeypad);	bExit.setBackground(exitColor);		bExit.setFocusable(false);
		bPowerOfTen.setFont(fontKeypad1);	bPowerOfTen.setBackground(otherColor);	bPowerOfTen.setFocusable(false);
		
		
		
		bOne.addActionListener(this);
		bTwo.addActionListener(this);
		bThree.addActionListener(this);
		bFour.addActionListener(this);
		bFive.addActionListener(this);
		bSix.addActionListener(this);
		bSeven.addActionListener(this);
		bEight.addActionListener(this);
		bNine.addActionListener(this);
		bZero.addActionListener(this);
		bAdd.addActionListener(this);
		bSub.addActionListener(this);
		bMul.addActionListener(this);
		bDiv.addActionListener(this);
		bPoint.addActionListener(this);
		bEqual.addActionListener(this);
		bClear.addActionListener(this);
		bSquare.addActionListener(this);
		bSqrt.addActionListener(this);
		bCube.addActionListener(this);
		bPercent.addActionListener(this);
		bMod.addActionListener(this);
		bOneByN.addActionListener(this);
		bPlusMinus.addActionListener(this);
		bSin.addActionListener(this);
		bCos.addActionListener(this);
		bTan.addActionListener(this);
		bAsin.addActionListener(this);
		bAcos.addActionListener(this);
		bAtan.addActionListener(this);
		bSinH.addActionListener(this);
		bCosH.addActionListener(this);
		bTanH.addActionListener(this);
		bPowerOfTen.addActionListener(this);
		bLog.addActionListener(this);
		bLn.addActionListener(this);
		bAbs.addActionListener(this);
		bExit.addActionListener(this);

	}


	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getSource() == bOne) 
		{
			if(operation == '=')
			{
				sDisplay = "1";
				sRawInput = "1";
				tfRawInput.setText(sRawInput);
				operation = ' ';
			}
			else 
			{
				sDisplay = sDisplay + "1";
				sRawInput += "1";
				tfRawInput.setText(sRawInput);
			}
		} 
		else if (e.getSource() == bTwo) 
		{
			if(operation == '=')
			{
				sDisplay = "2";
				sRawInput = "2";
				tfRawInput.setText(sRawInput);
				operation = ' ';
			}
			else 
			{
				sDisplay = sDisplay + "2";
				sRawInput += "2";
				tfRawInput.setText(sRawInput);
			}
		} 
		else if (e.getSource() == bThree)
		{
			if(operation == '=')
			{
				sDisplay = "3";
				sRawInput = "3";
				tfRawInput.setText(sRawInput);
				operation = ' ';
			}
			else 
			{
				sDisplay = sDisplay + "3";
				sRawInput += "3";
				tfRawInput.setText(sRawInput);
			}
		} 
		else if (e.getSource() == bFour) 
		{
			if(operation == '=')
			{
				sDisplay = "4";
				sRawInput = "4";
				tfRawInput.setText(sRawInput);
				operation = ' ';
			}
			else 
			{
				sDisplay = sDisplay + "4";
				sRawInput += "4";
				tfRawInput.setText(sRawInput);
			}
		} 
		else if (e.getSource() == bFive) 
		{
			if(operation == '=')
			{
				sDisplay = "5";
				sRawInput = "5";
				tfRawInput.setText(sRawInput);
				operation = ' ';
			}
			else 
			{
				sDisplay = sDisplay + "5";
				sRawInput += "5";
				tfRawInput.setText(sRawInput);
			}
		}
		else if (e.getSource() == bSix) 
		{
			if(operation == '=')
			{
				sDisplay = "6";
				sRawInput = "6";
				tfRawInput.setText(sRawInput);
				operation = ' ';
			}
			else 
			{
				sDisplay = sDisplay + "6";
				sRawInput += "6";
				tfRawInput.setText(sRawInput);
			}
		} 
		else if (e.getSource() == bSeven) 
		{
			if(operation == '=')
			{
				sDisplay = "7";
				sRawInput = "7";
				tfRawInput.setText(sRawInput);
				operation = ' ';
			}
			else 
			{
				sDisplay = sDisplay + "7";
				sRawInput += "7";
				tfRawInput.setText(sRawInput);
			}
		}
		else if (e.getSource() == bEight) 
		{
			if(operation == '=')
			{
				sDisplay = "8";
				sRawInput = "8";
				tfRawInput.setText(sRawInput);
				operation = ' ';
			}
			else 
			{
				sDisplay = sDisplay + "8";
				sRawInput += "8";
				tfRawInput.setText(sRawInput);
			}
		} 
		else if (e.getSource() == bNine) 
		{
			if(operation == '=')
			{
				sDisplay = "9";
				sRawInput = "9";
				tfRawInput.setText(sRawInput);
				operation = ' ';
			}
			else 
			{
				sDisplay = sDisplay + "9";
				sRawInput += "9";
				tfRawInput.setText(sRawInput);
			}
		} 
		else if (e.getSource() == bZero) 
		{
			if(sDisplay.equals(""))
			{
				sDisplay = "0";
				sRawInput += "0";
				tfRawInput.setText(sRawInput);
			}
			else
			{
				sDisplay = sDisplay + "0";
				sRawInput += "0";
				tfRawInput.setText(sRawInput);
			}
		} 
		else if (e.getSource() == bPoint) 
		{
			if(sDisplay.equals(""))
			{
				sDisplay = "0.";
				sRawInput += "0.";
				tfRawInput.setText(sRawInput);
			}
			else if(!isPoint)
			{
				sDisplay = sDisplay + ".";
				sRawInput += ".";
				tfRawInput.setText(sRawInput);
			}
			isPoint = true;
		} 
		else if(e.getSource() == bPlusMinus && !sDisplay.equals("") && !isOperation)
		{
			if(isPlus)
			{
				sDisplay = "-" + sDisplay;
				sRawInput = sDisplay;
				tfRawInput.setText(sRawInput);
				isPlus = false;
			}
			else
			{
				sDisplay = sDisplay.substring(1, sDisplay.length());
				sRawInput = sDisplay.substring(1, sDisplay.length());
				tfRawInput.setText(sRawInput);
				isPlus = true;
			}
		}
		else if (e.getSource() == bAdd && (!sDisplay.equals("") || operation == '='))
		{
			if(!isOperation)
			{
				number1 = Double.parseDouble(sDisplay);
				sDisplay = "";
				operation = '+';
				isPlus = true;
				sRawInput += " + ";
				tfRawInput.setText(sRawInput);
				if(isPoint)
				{
					tfDisplay.setText(""+number1);
				}
				else if(!isPoint)
				{
					tfDisplay.setText(""+(long)number1);
				}
			}
			else if(isOperation && operation != '=')
			{
				number2  = Double.parseDouble(sDisplay);
				
				if(operation == '+')
				{
					result = number1 + number2;
				}
				else if(operation == '-')
				{
					result = number1 - number2;
				}
				else if(operation == '*')
				{
					result = number1 * number2;
				}
				else if(operation == '/')
				{
					result = number1 / number2;
				}
				else if(operation == '%')
				{
					result = number1 % number2;
				}
				else
				{
					result = number2;
				}
				String temp = "";
				if(isPoint || operation == '/')
				{
					tfDisplay.setText(""+result);
					temp = ""+result;
				}
				else if(!isPoint)
				{
					tfDisplay.setText(""+(long)result);
					temp = ""+(long)result;
				}
				operation = '+';
				sDisplay = "";
				number1 = result;
				isPlus = true;
				isPoint = false;
				isOperation = true;
				sRawInput += " + ";
				tfRawInput.setText(sRawInput);
				sRawInput = temp + " + ";
			}
			else if(operation == '=')
			{
				sDisplay = "";
				operation = '+';
				isPlus = true;
				isOperation = true;
				sRawInput += " + ";
				tfRawInput.setText(sRawInput);
			}
			isOperation = true; 
		}
		else if (e.getSource() == bSub && (!sDisplay.equals("") || operation == '=')) 
		{
			if(!isOperation)
			{
				number1 = Double.parseDouble(sDisplay);
				sDisplay = "";
				operation = '-';
				isPlus = true;
				sRawInput += " - ";
				tfRawInput.setText(sRawInput);
				if(isPoint)
				{
					tfDisplay.setText(""+number1);
				}
				else if(!isPoint)
				{
					tfDisplay.setText(""+(long)number1);
				}
			}
			else if(isOperation && operation != '=')
			{
				number2  = Double.parseDouble(sDisplay);
				
				if(operation == '+')
				{
					result = number1 + number2;
				}
				else if(operation == '-')
				{
					result = number1 - number2;
				}
				else if(operation == '*')
				{
					result = number1 * number2;
				}
				else if(operation == '/')
				{
					result = number1 / number2;
				}
				else if(operation == '%')
				{
					result = number1 % number2;
				}
				else
				{
					result = number2;
				}
				String temp = "";
				if(isPoint || operation == '/')
				{
					tfDisplay.setText(""+result);
					temp = ""+result;
				}
				else if(!isPoint)
				{
					tfDisplay.setText(""+(long)result);
					temp = ""+(long)result;
				}
				operation = '-';
				sDisplay = "";
				number1 = result;
				isPlus = true;
				isPoint = false;
				isOperation = true; 
				sRawInput += " - ";
				tfRawInput.setText(sRawInput);
				sRawInput = temp + " + ";
			}
			else if(operation == '=')
			{
				sDisplay = "";
				operation = '-';
				isPlus = true;
				isOperation = true;
				sRawInput += " - ";
				tfRawInput.setText(sRawInput);
			}
			isOperation = true;
		}
		else if (e.getSource() == bMul && (!sDisplay.equals("") || operation == '=')) 
		{
			if(!isOperation)
			{
				number1 = Double.parseDouble(sDisplay);
				sDisplay = "";
				operation = '*';
				isPlus = true;
				sRawInput += " \u00D7 ";
				tfRawInput.setText(sRawInput);
				if(isPoint)
				{
					tfDisplay.setText(""+number1);
				}
				else if(!isPoint)
				{
					tfDisplay.setText(""+(long)number1);
				}
			}
			else if(isOperation && operation != '=')
			{
				number2  = Double.parseDouble(sDisplay);
				
				if(operation == '+')
				{
					result = number1 + number2;
				}
				else if(operation == '-')
				{
					result = number1 - number2;
				}
				else if(operation == '*')
				{
					result = number1 * number2;
				}
				else if(operation == '/')
				{
					result = number1 / number2;
				}
				else if(operation == '%')
				{
					result = number1 % number2;
				}
				else
				{
					result = number2;
				}
				String temp = "";
				if(isPoint || operation == '/')
				{
					tfDisplay.setText(""+result);
					temp = ""+result;
				}
				else if(!isPoint)
				{
					tfDisplay.setText(""+(long)result);
					temp = ""+(long)result;
				}
				operation = '*';
				sDisplay = "";
				number1 = result;
				isPlus = true;
				isPoint = false;
				isOperation = true;
				sRawInput += " \u00D7 ";
				tfRawInput.setText(sRawInput);
				sRawInput = temp + " \u00D7 ";
			}
			else if(operation == '=')
			{
				sDisplay = "";
				operation = '*';
				isPlus = true;
				isOperation = true;
				sRawInput += " \u00D7 ";
				tfRawInput.setText(sRawInput);
			}
			isOperation = true;
		}
		else if (e.getSource() == bDiv && (!sDisplay.equals("") || operation == '='))  
		{
			if(!isOperation)
			{
				number1 = Double.parseDouble(sDisplay);
				sDisplay = "";
				operation = '/';
				isPlus = true;
				sRawInput += " / ";
				tfRawInput.setText(sRawInput);
				if(isPoint)
				{
					tfDisplay.setText(""+number1);
				}
				else if(!isPoint)
				{
					tfDisplay.setText(""+(long)number1);
				}
			}
			else if(isOperation && operation != '=')
			{
				number2  = Double.parseDouble(sDisplay);
				
				if(operation == '+')
				{
					result = number1 + number2;
				}
				else if(operation == '-')
				{
					result = number1 - number2;
				}
				else if(operation == '*')
				{
					result = number1 * number2;
				}
				else if(operation == '/')
				{
					result = number1 / number2;
				}
				else if(operation == '%')
				{
					result = number1 % number2;
				}
				else
				{
					result = number2;
				}
				String temp = "";
				if(isPoint || operation == '/')
				{
					tfDisplay.setText(""+result);
					temp = ""+result;
				}
				else if(!isPoint)
				{
					tfDisplay.setText(""+(long)result);
					temp = ""+(long)result;
				}
				operation = '*';
				sDisplay = "";
				number1 = result;
				isPlus = true;
				isPoint = false;
				isOperation = true;
				sRawInput += " / ";
				tfRawInput.setText(sRawInput);
				sRawInput = temp + " / ";
			}
			else if(operation == '=')
			{
				sDisplay = "";
				operation = '/';
				isPlus = true;
				isOperation = true;
				sRawInput += " / ";
				tfRawInput.setText(sRawInput);
			}
			isOperation = true;
		} 
		else if (e.getSource() == bMod && (!sDisplay.equals("") || operation == '='))
		{
			if(!isOperation)
			{
				number1 = Double.parseDouble(sDisplay);
				sDisplay = "";
				operation = '%';
				isPlus = true;
				sRawInput += " mod ";
				tfRawInput.setText(sRawInput);
				if(isPoint)
				{
					tfDisplay.setText(""+number1);
				}
				else if(!isPoint)
				{
					tfDisplay.setText(""+(long)number1);
				}
			}
			else if(isOperation && operation != '=')
			{
				number2  = Double.parseDouble(sDisplay);
				
				if(operation == '+')
				{
					result = number1 + number2;
				}
				else if(operation == '-')
				{
					result = number1 - number2;
				}
				else if(operation == '*')
				{
					result = number1 * number2;
				}
				else if(operation == '/')
				{
					result = number1 / number2;
				}
				else if(operation == '%')
				{
					result = number1 % number2;
				}
				else
				{
					result = number2;
				}
				String temp = "";
				if(isPoint || operation == '/')
				{
					tfDisplay.setText(""+result);
					temp = ""+result;
				}
				else if(!isPoint)
				{
					tfDisplay.setText(""+(long)result);
					temp = ""+(long)result;
				}
				operation = '%';
				sDisplay = "";
				number1 = result;
				isPlus = true;
				isPoint = false;
				isOperation = true;
				sRawInput += " mod ";
				tfRawInput.setText(sRawInput);
				sRawInput = temp + " * ";
			}
			else if(operation == '=')
			{
				sDisplay = "";
				operation = '%';
				isPlus = true;
				isOperation = true;
				sRawInput += " mod ";
				tfRawInput.setText(sRawInput);
			}
			isOperation = true;
		}
		else if (e.getSource() == bEqual && !sDisplay.equals(""))
		{
			number2  = Double.parseDouble(sDisplay);
			
			if(operation == '+')
			{
				result = number1 + number2;
			}
			else if(operation == '-')
			{
				result = number1 - number2;
			}
			else if(operation == '*')
			{
				result = number1 * number2;
			}
			else if(operation == '/')
			{
				result = number1 / number2;
			}
			else if(operation == '%')
			{
				result = number1 % number2;
			}
			else
			{
				result = number2;
			}
			String temp = "";
			if(isPoint || operation == '/')
			{
				tfDisplay.setText(""+result);
				temp = ""+result;
			}
			else if(!isPoint)
			{
				tfDisplay.setText(""+(long)result);
				temp = ""+(long)result;
			}
			sDisplay = "";
			number1 = result;
			isPlus = true;
			isPoint = false;
			isOperation = true;
			sRawInput += " = ";
			tfRawInput.setText(sRawInput);
			sRawInput = temp;
			operation = '=';
		} 
	
		else if (e.getSource() == bClear) 
		{
			number1 = number2 = result = 0;
			sDisplay = "";
			operation = ' ';
			tfDisplay.setText("0");
			isPoint = false;
			isPlus = true;
			isOperation = false;
			sRawInput = "";
			tfRawInput.setText("0");
		} 
		else if (e.getSource() == bSquare && !sDisplay.equals("")) 
		{
			number1 = Double.parseDouble(sDisplay);
			result = Math.pow(number1, 2);
			String temp = "";
			if(!isPoint)
			{
				tfDisplay.setText(""+(long)result);
				temp = ""+(long)result;
			}
			else 
			{
				tfDisplay.setText(""+result);
				temp = ""+result;
			}
			sRawInput += "^2 = ";
			tfRawInput.setText(sRawInput);
			sRawInput = temp;
			sDisplay = "";
			number1 = result;
			operation = '=';
			isPoint = false;
			isOperation = true;
			isPlus = true;
		} 
		else if (e.getSource() == bSqrt && !sDisplay.equals("")) 
		{
			number1 = Double.parseDouble(sDisplay);
			result = Math.sqrt(number1);
			sRawInput =  "\u221A" + sRawInput;
			tfRawInput.setText(sRawInput);
			tfDisplay.setText(""+result);
			sRawInput = ""+result;
			sDisplay = "";
			number1 = result;
			operation = '=';
			isPoint = true;
			isOperation = true;
			isPlus = true;
		}
		else if (e.getSource() == bCube && !sDisplay.equals("")) 
		{
			number1 = Double.parseDouble(sDisplay);
			result = Math.pow(number1, 3);
			String temp = "";
			if(!isPoint)
			{
				tfDisplay.setText(""+(long)result);
				temp = ""+(long)result;
			}
			else 
			{
				tfDisplay.setText(""+result);
				temp = ""+result;
			}
			sRawInput +="^3 = ";
			tfRawInput.setText(sRawInput);
			sRawInput = temp;
			sDisplay = "";
			number1 = result;
			operation = '=';
			isPoint = false;
			isOperation = true;
			isPlus = true;
			
		}
		else if (e.getSource() == bOneByN && !sDisplay.equals(""))
		{
			number1 = Double.parseDouble(sDisplay);
			result = 1 / number1;
			if(isPoint)
			{
				sRawInput = "1 / " + number1;
			}
			else 
			{
				sRawInput = "1 / " + (long)number1;
			}
			tfRawInput.setText(sRawInput);
			tfDisplay.setText(""+result);
			sDisplay = "";
			sRawInput = ""+result;
			number1 = result;
			operation = '=';
			isPoint = true;
			isOperation = true;
			isPlus = true;
		}
		else if(e.getSource() == bPercent && !sDisplay.equals("") && operation=='*')
		{
			number2  = Double.parseDouble(sDisplay);
			result = number1 * (number2 / 100);
			sRawInput = number1+" \u00D7 "+number2+"%";
			tfRawInput.setText(sRawInput);
			tfDisplay.setText(""+result);
			sDisplay = "";
			number1 = result;
			operation = '=';
			isPlus = true;
			isOperation = true;
			isPoint = true;
			sRawInput = ""+result;
		}
		else if(e.getSource() == bSin && !sDisplay.equals(""))
		{
			number1 = Double.parseDouble(sDisplay);
			if(number1 == 30)
			{
				result = Math.sin(Math.toRadians(number1)) + 0.0000000000000001;
			}
			else
			{
				result = Math.sin(Math.toRadians(number1));
			}
			sRawInput =  "sin("+sRawInput+")";
			tfRawInput.setText(sRawInput);
			tfDisplay.setText(""+result);
			sRawInput = ""+result;
			sDisplay = "";
			number1 = result;
			operation = '=';
			isPoint = true;
			isOperation = true;
			isPlus = true;
		}
		else if(e.getSource() == bCos && !sDisplay.equals(""))
		{
			number1 = Double.parseDouble(sDisplay);
			if(number1 == 60)
			{
				result = Math.cos(Math.toRadians(number1)) - 0.0000000000000001;
			}
			else if (number1 == 90)
			{
				result = 0;
			}
			else 
			{
				result = Math.cos(Math.toRadians(number1));
			}
			sRawInput =  "cos("+sRawInput+")";
			tfRawInput.setText(sRawInput);
			tfDisplay.setText(""+result);
			sRawInput = ""+result;
			sDisplay = "";
			number1 = result;
			operation = '=';
			isPoint = true;
			isOperation = true;
			isPlus = true;
		}
		else if(e.getSource() == bTan && !sDisplay.equals(""))
		{
			number1 = Double.parseDouble(sDisplay);
			if(number1 == 45)
			{
				result = Math.tan(Math.toRadians(number1)) + 0.0000000000000001;
			}
			else if(number1 == 90)
			{
				result = 0;
				tfDisplay.setText("Invalid");
			}
			else
			{
				result = Math.tan(Math.toRadians(number1));
			}
			sRawInput =  "tan("+sRawInput+")";
			tfRawInput.setText(sRawInput);
			if(number1 != 90)
			{
				tfDisplay.setText(""+result);
			}
			sRawInput = ""+result;
			sDisplay = "";
			number1 = result;
			operation = '=';
			isPoint = true;
			isOperation = true;
			isPlus = true;
		}
		else if(e.getSource() == bSinH && !sDisplay.equals(""))
		{
			number1 = Double.parseDouble(sDisplay);
			result = Math.sinh(Math.toRadians(number1));
			sRawInput =  "sinh("+sRawInput+")";
			tfRawInput.setText(sRawInput);
			tfDisplay.setText(""+result);
			sRawInput = ""+result;
			sDisplay = "";
			number1 = result;
			operation = '=';
			isPoint = true;
			isOperation = true;
			isPlus = true;
		}
		else if(e.getSource() == bCosH && !sDisplay.equals(""))
		{
			number1 = Double.parseDouble(sDisplay);
			result = Math.cosh(Math.toRadians(number1));
			sRawInput =  "cosh("+sRawInput+")";
			tfRawInput.setText(sRawInput);
			tfDisplay.setText(""+result);
			sRawInput = ""+result;
			sDisplay = "";
			number1 = result;
			operation = '=';
			isPoint = true;
			isOperation = true;
			isPlus = true;
		}
		else if(e.getSource() == bTanH && !sDisplay.equals(""))
		{
			number1 = Double.parseDouble(sDisplay);
			result = Math.tanh(Math.toRadians(number1));
			sRawInput =  "tanH("+sRawInput+")";
			tfRawInput.setText(sRawInput);
			tfDisplay.setText(""+result);
			sRawInput = ""+result;
			sDisplay = "";
			number1 = result;
			operation = '=';
			isPoint = true;
			isOperation = true;
			isPlus = true;
		}
		else if(e.getSource() == bAsin && !sDisplay.equals(""))
		{
			number1 = Double.parseDouble(sDisplay);
			result = Math.asin(Math.toRadians(number1));
			sRawInput =  "asin("+sRawInput+")";
			tfRawInput.setText(sRawInput);
			tfDisplay.setText(""+result);
			sRawInput = ""+result;
			sDisplay = "";
			number1 = result;
			operation = '=';
			isPoint = true;
			isOperation = true;
			isPlus = true;
		}
		else if(e.getSource() == bAcos && !sDisplay.equals(""))
		{
			number1 = Double.parseDouble(sDisplay);
			result = Math.acos(Math.toRadians(number1));
			sRawInput =  "acos("+sRawInput+")";
			tfRawInput.setText(sRawInput);
			tfDisplay.setText(""+result);
			sRawInput = ""+result;
			sDisplay = "";
			number1 = result;
			operation = '=';
			isPoint = true;
			isOperation = true;
			isPlus = true;
		}
		else if(e.getSource() == bAtan && !sDisplay.equals(""))
		{
			number1 = Double.parseDouble(sDisplay);
			result = Math.atan(Math.toRadians(number1));
			sRawInput =  "atan("+sRawInput+")";
			tfRawInput.setText(sRawInput);
			tfDisplay.setText(""+result);
			sRawInput = ""+result;
			sDisplay = "";
			number1 = result;
			operation = '=';
			isPoint = true;
			isOperation = true;
			isPlus = true;
		}
		else if(e.getSource() == bLog && !sDisplay.equals(""))
		{
			number1 = Double.parseDouble(sDisplay);
			result = Math.log10(number1);
			sRawInput =  "log"+sRawInput;
			tfRawInput.setText(sRawInput);
			tfDisplay.setText(""+result);
			sRawInput = ""+result;
			sDisplay = "";
			number1 = result;
			operation = '=';
			isPoint = true;
			isOperation = true;
			isPlus = true;
		}
		else if(e.getSource() == bLn && !sDisplay.equals(""))
			
		{
			number1 = Double.parseDouble(sDisplay);
			result = Math.log(number1);
			sRawInput =  "ln"+sRawInput;
			tfRawInput.setText(sRawInput);
			tfDisplay.setText(""+result);
			sRawInput = ""+result;
			sDisplay = "";
			number1 = result;
			operation = '=';
			isPoint = true;
			isOperation = true;
			isPlus = true;
		}
		else if(e.getSource() == bAbs && !sDisplay.equals("")) 
			 
		{
			number1 = Double.parseDouble(sDisplay);
			result = Math.abs(number1);
			sRawInput =  "abs("+sRawInput+")";
			tfRawInput.setText(sRawInput);
			tfDisplay.setText(""+result);
			sRawInput = ""+result;
			sDisplay = "";
			number1 = result;
			operation = '=';
			isPoint = true;
			isOperation = true;
			isPlus = true;
		}
		else if(e.getSource() == bPowerOfTen && !sDisplay.equals(""))
		{
			number1 = Double.parseDouble(sDisplay);
			result = Math.pow(10, number1);
			sRawInput =  "10^"+sRawInput;
			tfRawInput.setText(sRawInput);
			tfDisplay.setText(""+result);
			sRawInput = ""+result;
			sDisplay = "";
			number1 = result;
			operation = '=';
			isPoint = true;
			isOperation = true;
			isPlus = true;
		}
		else if(e.getSource() == bExit)
		
		{
			System.exit(0);
		}
	}

	



	}

