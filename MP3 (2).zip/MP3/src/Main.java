import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.Color.*;
import java.awt.Rectangle;

import javax.swing.JFrame;

public class Main {

	public static void main(String[] CHAND) {
		// TODO Auto-generated method stub
		CalculatorLayout frame = new CalculatorLayout();
		frame.setTitle("CI- Calculator");
		frame.setSize(350, 500);
		frame.setLocationRelativeTo(null);
		frame.setMaximizedBounds(new Rectangle(300, 200));
		frame.setResizable(false);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
}
	